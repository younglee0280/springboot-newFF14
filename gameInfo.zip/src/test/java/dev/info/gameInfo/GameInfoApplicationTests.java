package dev.info.gameInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
