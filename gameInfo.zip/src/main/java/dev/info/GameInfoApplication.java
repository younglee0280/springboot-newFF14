package dev.info;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameInfoApplication.class, args);
	}
}
