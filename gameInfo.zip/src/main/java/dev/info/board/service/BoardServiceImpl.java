package dev.info.board.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dev.info.Entity.Board;
import dev.info.board.repository.BoardRepository;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardRepository boardRepository;

	//findAllId
	//findBoardById
	//findBoardByTitle
	
	@Override
	//글 작성
	public Board writeBoard(Board newBoard) {

		return boardRepository.save(newBoard);
	}
	
	//글 저장
	@Override
	public Board saveBoard(Board newBoard) {
		return boardRepository.save(newBoard);
	}
	
	//전체 글 조회
	@Override
	public List<Board> findAllBoards() {
		return boardRepository.findAll();
	}

//	//글 수정
//	@Override
//	public Board editBoard(Board editBoard) {
//	
//		return boardRepository.save(editBoard);
//	}
}
