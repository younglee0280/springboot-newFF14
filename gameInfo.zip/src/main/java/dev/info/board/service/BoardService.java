package dev.info.board.service;

import java.util.List;

import org.springframework.stereotype.Service;

import dev.info.Entity.Board;

public interface BoardService {
	//글 작성
	Board writeBoard(Board newBoard);
	
	//글 저장
	Board saveBoard(Board newBoard);
	
	//전체 글 조회
	List<Board> findAllBoards();
	
	//글 수정
//	Board editBoard(Board editBoard);
	
	//글 조회
	
	
	//글 한 개씩 삭제
	
}
