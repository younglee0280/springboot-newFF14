package dev.info.board.controller;

import java.util.List;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import dev.info.Entity.Board;
import dev.info.board.repository.BoardRepository;
import dev.info.board.service.BoardService;
@RestController //restAPI 컨트롤러 선언
@RequestMapping("/board") //경로 설정
@CrossOrigin(" * ")
//URL path 정의해서 어떤 작업할지 정의해주기

public class BoardController {
	@Autowired
	private BoardService boardService;	//boardService 가져오기
	
	@Autowired
	private BoardRepository boardRepository;
	
	//글 작성 - post
	@PostMapping(path= "/write")
	public ResponseEntity<Board.Response> 
	createBoard(@RequestBody @Valid Board.Request request) { //@RequestBody 옆에 @Valid를 작성하면 RequestBody로 들어오는 객체에 대한 유효성 검사를 실시한다. 
		
		Board board = Board.Request.toEntity(request);
		
		//글 저장
		Board wroteBoard = boardService.writeBoard(board);
		Board.Response response = Board.Response.toResponse(wroteBoard);
		
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
		
	}

	public BoardController(BoardService boardService) {
		this.boardService = boardService;
	}
	
	//모든 글을 불러오기 - 전체 글 조회
	@GetMapping(path= "/boards")   //write
	public List<Board.Response> getBoards() {

		List<Board> boards = boardService.findAllBoards();
		List<Board.Response> response = Board.Response.toResponseList(boards);

		return response;
	}
	

	
//	//글 수정
//	@PutMapping
//	public void editBoard(@RequestBody Board.Request request) {
//	
//	}


}
